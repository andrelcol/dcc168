package jogodavida;

public class Celula {
    private boolean viva;

    public Celula() {
        this.viva = false;
    }

    public boolean isViva() {
        return viva;
    }

    public void setViva(boolean viva) {
        this.viva = viva;
    }
} 